#!/bin/bash

# Script deploy nhanh lên Google Cloud Run
# Sử dụng: ./deploy.sh

echo "🚀 Deploying Binance P2P API to Google Cloud Run..."
echo ""

# Kiểm tra gcloud đã cài chưa
if ! command -v gcloud &> /dev/null; then
    echo "❌ Google Cloud SDK chưa được cài đặt!"
    echo "📥 Vui lòng cài đặt từ: https://cloud.google.com/sdk/docs/install"
    exit 1
fi

# Lấy project ID hiện tại
PROJECT_ID=$(gcloud config get-value project 2>/dev/null)

if [ -z "$PROJECT_ID" ]; then
    echo "⚠️  Chưa có project được chọn!"
    echo "📝 Vui lòng chạy: gcloud config set project YOUR_PROJECT_ID"
    exit 1
fi

echo "📦 Project: $PROJECT_ID"
echo ""

# Cấu hình
SERVICE_NAME="binance-p2p-api"
REGION="asia-southeast1"
MEMORY="256Mi"
CPU="1"
MAX_INSTANCES="3"
MIN_INSTANCES="0"

echo "⚙️  Cấu hình deploy:"
echo "   - Service: $SERVICE_NAME"
echo "   - Region: $REGION (Singapore)"
echo "   - Memory: $MEMORY"
echo "   - CPU: $CPU"
echo "   - Max Instances: $MAX_INSTANCES"
echo "   - Min Instances: $MIN_INSTANCES"
echo ""

read -p "Bạn có muốn tiếp tục? (y/n) " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Hủy deploy"
    exit 1
fi

echo ""
echo "🔨 Bắt đầu deploy..."
echo ""

# Deploy
gcloud run deploy $SERVICE_NAME \
  --source . \
  --platform managed \
  --region $REGION \
  --allow-unauthenticated \
  --memory $MEMORY \
  --cpu $CPU \
  --min-instances $MIN_INSTANCES \
  --max-instances $MAX_INSTANCES

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Deploy thành công!"
    echo ""
    
    # Lấy URL
    SERVICE_URL=$(gcloud run services describe $SERVICE_NAME \
      --platform managed \
      --region $REGION \
      --format 'value(status.url)')
    
    echo "🌐 URL của API:"
    echo "   $SERVICE_URL"
    echo ""
    echo "📚 Các endpoints có sẵn:"
    echo "   GET  $SERVICE_URL/"
    echo "   GET  $SERVICE_URL/health"
    echo "   GET  $SERVICE_URL/api/price/buy"
    echo "   GET  $SERVICE_URL/api/price/sell"
    echo "   GET  $SERVICE_URL/api/price/both"
    echo "   GET  $SERVICE_URL/api/price/best"
    echo ""
    echo "🧪 Test ngay:"
    echo "   curl $SERVICE_URL/health"
    echo "   curl $SERVICE_URL/api/price/best"
    echo ""
else
    echo ""
    echo "❌ Deploy thất bại!"
    echo "📋 Xem logs: gcloud logging read \"resource.type=cloud_run_revision\" --limit 50"
    exit 1
fi
