# 🚀 QUICK START - Deploy trong 3 phút!

## Bước 1: Cài Google Cloud SDK

### Windows
1. Tải: https://cloud.google.com/sdk/docs/install
2. Chạy installer và làm theo hướng dẫn

### macOS
```bash
brew install google-cloud-sdk
```

### Linux
```bash
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
```

## Bước 2: Khởi tạo

```bash
# Đăng nhập
gcloud auth login

# Tạo project mới
gcloud projects create binance-p2p-api --name="Binance P2P API"

# Set project
gcloud config set project binance-p2p-api

# Enable APIs
gcloud services enable run.googleapis.com cloudbuild.googleapis.com
```

## Bước 3: Deploy (Chọn 1 trong 2 cách)

### Cách 1: Dùng script tự động (Dễ nhất)
```bash
chmod +x deploy.sh
./deploy.sh
```

### Cách 2: Deploy thủ công
```bash
gcloud run deploy binance-p2p-api \
  --source . \
  --platform managed \
  --region asia-southeast1 \
  --allow-unauthenticated \
  --memory 256Mi
```

## Bước 4: Test API

Sau khi deploy xong, bạn sẽ nhận được URL như:
```
https://binance-p2p-api-xxxxx-as.a.run.app
```

Test ngay:
```bash
# Health check
curl https://YOUR_URL/health

# Giá tốt nhất
curl https://YOUR_URL/api/price/best

# Giá mua USDT
curl https://YOUR_URL/api/price/buy?rows=5

# Giá bán USDT  
curl https://YOUR_URL/api/price/sell?rows=5
```

## 🎯 Các API Endpoints

| Endpoint | Mô tả |
|----------|-------|
| `GET /` | Thông tin API |
| `GET /health` | Health check |
| `GET /api/price/buy` | Giá MUA USDT (trả VND) |
| `GET /api/price/sell` | Giá BÁN USDT (nhận VND) |
| `GET /api/price/both` | Cả 2 giá |
| `GET /api/price/best` | Giá tốt nhất + spread |

## 💰 Chi Phí

**MIỄN PHÍ** với:
- < 2 triệu requests/tháng
- < 360,000 GB-seconds
- < 180,000 vCPU-seconds

Config hiện tại (256Mi, 1 CPU, min=0) sẽ scale về 0 khi không dùng = **$0/tháng**!

## 🔧 Commands Hữu Ích

```bash
# Xem URL
gcloud run services describe binance-p2p-api \
  --region asia-southeast1 \
  --format 'value(status.url)'

# Xem logs
gcloud logging read "resource.type=cloud_run_revision" --limit 50

# Update service
gcloud run deploy binance-p2p-api --source . --region asia-southeast1

# Xóa service
gcloud run services delete binance-p2p-api --region asia-southeast1
```

## 📝 Lưu Ý

1. **Cần billing account**: Google Cloud yêu cầu thêm thẻ tín dụng nhưng KHÔNG tự động charge nếu ở trong free tier
2. **Region**: Dùng `asia-southeast1` (Singapore) để gần VN
3. **Cold start**: Request đầu tiên có thể chậm 2-5s

## 🆘 Troubleshooting

### Lỗi "Permission denied"
```bash
gcloud services enable run.googleapis.com cloudbuild.googleapis.com
```

### Lỗi "Billing account required"
1. Vào https://console.cloud.google.com/billing
2. Thêm billing account (cần thẻ visa/master)
3. Link billing account với project

### API không chạy
```bash
# Check logs
gcloud logging read "resource.type=cloud_run_revision" --limit 100

# Test local trước
npm install
npm start
```

---

**🎉 Xong! API của bạn đã live trên Google Cloud!**

Đọc thêm chi tiết trong `README.md`
