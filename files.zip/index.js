const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(express.json());

// Binance P2P API endpoint
const BINANCE_P2P_API = 'https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search';

/**
 * Lấy giá USDT từ Binance P2P
 * @param {string} tradeType - 'BUY' hoặc 'SELL'
 * @param {string} asset - Coin (mặc định 'USDT')
 * @param {string} fiat - Tiền tệ (mặc định 'VND')
 * @param {number} page - Trang
 * @param {number} rows - Số lượng kết quả
 */
async function getBinanceP2PPrice(tradeType, asset = 'USDT', fiat = 'VND', page = 1, rows = 10) {
  try {
    const response = await axios.post(BINANCE_P2P_API, {
      page,
      rows,
      asset,
      fiat,
      tradeType,
      payTypes: [],
      publisherType: null
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    return response.data;
  } catch (error) {
    throw new Error(`Binance API Error: ${error.message}`);
  }
}

/**
 * Xử lý và format dữ liệu giá
 */
function formatPriceData(data) {
  if (!data || !data.data || data.data.length === 0) {
    return null;
  }

  return data.data.map(item => ({
    advertiser: {
      nickName: item.advertiser.nickName,
      monthOrderCount: item.advertiser.monthOrderCount,
      monthFinishRate: item.advertiser.monthFinishRate,
      positiveRate: item.advertiser.positiveRate,
      userType: item.advertiser.userType,
      badges: item.advertiser.badges
    },
    adv: {
      advNo: item.adv.advNo,
      tradeType: item.adv.tradeType,
      asset: item.adv.asset,
      fiatUnit: item.adv.fiatUnit,
      price: parseFloat(item.adv.price),
      surplusAmount: parseFloat(item.adv.surplusAmount),
      minSingleTransAmount: parseFloat(item.adv.minSingleTransAmount),
      maxSingleTransAmount: parseFloat(item.adv.maxSingleTransAmount),
      minSingleTransQuantity: parseFloat(item.adv.minSingleTransQuantity),
      maxSingleTransQuantity: parseFloat(item.adv.maxSingleTransQuantity),
      payTimeLimit: item.adv.payTimeLimit,
      tradeMethods: item.adv.tradeMethods.map(method => ({
        payType: method.payType,
        tradeMethodName: method.tradeMethodName
      }))
    }
  }));
}

// ============= ROUTES =============

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'Binance P2P USDT Price API',
    version: '1.0.0',
    endpoints: {
      'GET /': 'API information',
      'GET /health': 'Health check',
      'GET /api/price/buy': 'Get USDT buy price (người mua USDT - trả VND)',
      'GET /api/price/sell': 'Get USDT sell price (người bán USDT - nhận VND)',
      'GET /api/price/both': 'Get both buy and sell prices',
      'GET /api/price/best': 'Get best buy and sell prices'
    },
    usage: {
      buy: '/api/price/buy?rows=5',
      sell: '/api/price/sell?rows=5',
      both: '/api/price/both',
      best: '/api/price/best'
    }
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

// Lấy giá MUA USDT (tradeType = BUY nghĩa là bạn MUA USDT từ người bán)
app.get('/api/price/buy', async (req, res) => {
  try {
    const rows = parseInt(req.query.rows) || 10;
    const page = parseInt(req.query.page) || 1;
    
    const data = await getBinanceP2PPrice('BUY', 'USDT', 'VND', page, rows);
    const formatted = formatPriceData(data);

    res.json({
      success: true,
      type: 'BUY',
      description: 'Giá mua USDT (bạn trả VND để mua USDT)',
      total: data.total,
      data: formatted
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Lấy giá BÁN USDT (tradeType = SELL nghĩa là bạn BÁN USDT để nhận VND)
app.get('/api/price/sell', async (req, res) => {
  try {
    const rows = parseInt(req.query.rows) || 10;
    const page = parseInt(req.query.page) || 1;
    
    const data = await getBinanceP2PPrice('SELL', 'USDT', 'VND', page, rows);
    const formatted = formatPriceData(data);

    res.json({
      success: true,
      type: 'SELL',
      description: 'Giá bán USDT (bạn nhận VND khi bán USDT)',
      total: data.total,
      data: formatted
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Lấy cả 2 giá mua và bán
app.get('/api/price/both', async (req, res) => {
  try {
    const rows = parseInt(req.query.rows) || 5;
    
    const [buyData, sellData] = await Promise.all([
      getBinanceP2PPrice('BUY', 'USDT', 'VND', 1, rows),
      getBinanceP2PPrice('SELL', 'USDT', 'VND', 1, rows)
    ]);

    const buyFormatted = formatPriceData(buyData);
    const sellFormatted = formatPriceData(sellData);

    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      buy: {
        description: 'Giá mua USDT (bạn trả VND)',
        total: buyData.total,
        data: buyFormatted
      },
      sell: {
        description: 'Giá bán USDT (bạn nhận VND)',
        total: sellData.total,
        data: sellFormatted
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Lấy giá tốt nhất (giá đầu tiên của mỗi loại)
app.get('/api/price/best', async (req, res) => {
  try {
    const [buyData, sellData] = await Promise.all([
      getBinanceP2PPrice('BUY', 'USDT', 'VND', 1, 1),
      getBinanceP2PPrice('SELL', 'USDT', 'VND', 1, 1)
    ]);

    const bestBuy = buyData.data[0];
    const bestSell = sellData.data[0];

    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      summary: {
        bestBuyPrice: parseFloat(bestBuy.adv.price),
        bestSellPrice: parseFloat(bestSell.adv.price),
        spread: parseFloat(bestBuy.adv.price) - parseFloat(bestSell.adv.price),
        spreadPercent: ((parseFloat(bestBuy.adv.price) - parseFloat(bestSell.adv.price)) / parseFloat(bestSell.adv.price) * 100).toFixed(2) + '%'
      },
      buy: {
        description: 'Giá tốt nhất để MUA USDT',
        price: parseFloat(bestBuy.adv.price),
        advertiser: bestBuy.advertiser.nickName,
        minAmount: parseFloat(bestBuy.adv.minSingleTransAmount),
        maxAmount: parseFloat(bestBuy.adv.maxSingleTransAmount),
        available: parseFloat(bestBuy.adv.surplusAmount)
      },
      sell: {
        description: 'Giá tốt nhất để BÁN USDT',
        price: parseFloat(bestSell.adv.price),
        advertiser: bestSell.advertiser.nickName,
        minAmount: parseFloat(bestSell.adv.minSingleTransAmount),
        maxAmount: parseFloat(bestSell.adv.maxSingleTransAmount),
        available: parseFloat(bestSell.adv.surplusAmount)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found',
    availableEndpoints: [
      'GET /',
      'GET /health',
      'GET /api/price/buy',
      'GET /api/price/sell',
      'GET /api/price/both',
      'GET /api/price/best'
    ]
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    error: 'Internal server error'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Binance P2P API running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🌐 Health check: http://localhost:${PORT}/health`);
});
