# 🚀 Binance P2P USDT API - Hướng Dẫn Deploy lên Google Cloud Run

## 📋 Tổng Quan

API này lấy giá USDT/VND từ Binance P2P marketplace với các tính năng:
- ✅ Lấy giá MUA USDT (bạn trả VND)
- ✅ Lấy giá BÁN USDT (bạn nhận VND)
- ✅ So sánh giá tốt nhất
- ✅ Tính spread và % chênh lệch

## 🎯 API Endpoints

### 1. Root Information
```
GET /
```
Trả về thông tin API và danh sách endpoints

### 2. Health Check
```
GET /health
```
Kiểm tra trạng thái API

### 3. Giá MUA USDT
```
GET /api/price/buy?rows=5&page=1
```
Lấy danh sách giá MUA USDT (bạn trả VND để mua USDT)

**Query Parameters:**
- `rows`: Số lượng kết quả (mặc định: 10)
- `page`: Trang (mặc định: 1)

### 4. Giá BÁN USDT
```
GET /api/price/sell?rows=5&page=1
```
Lấy danh sách giá BÁN USDT (bạn bán USDT để nhận VND)

### 5. Cả 2 Giá
```
GET /api/price/both?rows=5
```
Lấy đồng thời giá mua và bán

### 6. Giá Tốt Nhất
```
GET /api/price/best
```
Lấy giá tốt nhất và tính spread

**Response Example:**
```json
{
  "success": true,
  "timestamp": "2025-12-17T10:30:00.000Z",
  "summary": {
    "bestBuyPrice": 27210,
    "bestSellPrice": 26900,
    "spread": 310,
    "spreadPercent": "1.15%"
  },
  "buy": {
    "description": "Giá tốt nhất để MUA USDT",
    "price": 27210,
    "advertiser": "MuaBanUSDT-VND",
    "minAmount": 150000,
    "maxAmount": 300000,
    "available": 1744765.98
  },
  "sell": {
    "description": "Giá tốt nhất để BÁN USDT",
    "price": 26900,
    "advertiser": "MuaBanUSDT-VND",
    "minAmount": 150000,
    "maxAmount": 200000,
    "available": 154.00
  }
}
```

---

## 🛠️ Cài Đặt & Chạy Local

### Bước 1: Cài đặt dependencies
```bash
npm install
```

### Bước 2: Chạy development
```bash
npm run dev
```

### Bước 3: Chạy production
```bash
npm start
```

API sẽ chạy tại: `http://localhost:8080`

### Test API:
```bash
# Test health
curl http://localhost:8080/health

# Test giá tốt nhất
curl http://localhost:8080/api/price/best

# Test giá mua
curl http://localhost:8080/api/price/buy?rows=3
```

---

## ☁️ Deploy lên Google Cloud Run (MIỄN PHÍ)

### 📌 Yêu Cầu
1. Tài khoản Google Cloud (có $300 free credit cho new users)
2. Google Cloud SDK đã cài đặt

### Bước 1: Cài đặt Google Cloud SDK

**Windows:**
```bash
# Tải từ: https://cloud.google.com/sdk/docs/install
# Hoặc dùng PowerShell:
(New-Object Net.WebClient).DownloadFile("https://dl.google.com/dl/cloudsdk/channels/rapid/GoogleCloudSDKInstaller.exe", "$env:Temp\GoogleCloudSDKInstaller.exe")
& $env:Temp\GoogleCloudSDKInstaller.exe
```

**macOS:**
```bash
# Dùng Homebrew:
brew install google-cloud-sdk
```

**Linux:**
```bash
# Ubuntu/Debian:
echo "deb [signed-by=/usr/share/keyrings/cloud.google.gpg] https://packages.cloud.google.com/apt cloud-sdk main" | sudo tee -a /etc/apt/sources.list.d/google-cloud-sdk.list
curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key --keyring /usr/share/keyrings/cloud.google.gpg add -
sudo apt-get update && sudo apt-get install google-cloud-sdk
```

### Bước 2: Khởi tạo và đăng nhập
```bash
# Đăng nhập Google Cloud
gcloud auth login

# Tạo project mới (hoặc dùng project có sẵn)
gcloud projects create binance-p2p-api --name="Binance P2P API"

# Set project hiện tại
gcloud config set project binance-p2p-api

# Enable Cloud Run API
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
```

### Bước 3: Deploy lên Cloud Run

**Cách 1: Deploy từ source code (Đơn giản nhất)**
```bash
# Deploy trực tiếp từ thư mục source
gcloud run deploy binance-p2p-api \
  --source . \
  --platform managed \
  --region asia-southeast1 \
  --allow-unauthenticated \
  --memory 256Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 3

# asia-southeast1 = Singapore (gần VN nhất)
```

**Cách 2: Deploy từ Docker image**
```bash
# Build và push image lên Container Registry
gcloud builds submit --tag gcr.io/binance-p2p-api/api

# Deploy từ image
gcloud run deploy binance-p2p-api \
  --image gcr.io/binance-p2p-api/api \
  --platform managed \
  --region asia-southeast1 \
  --allow-unauthenticated \
  --memory 256Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 3
```

### Bước 4: Lấy URL và Test
```bash
# Lấy URL của service
gcloud run services describe binance-p2p-api \
  --platform managed \
  --region asia-southeast1 \
  --format 'value(status.url)'

# URL sẽ có dạng: https://binance-p2p-api-xxxxx-as.a.run.app
```

### Test API đã deploy:
```bash
# Thay YOUR_URL bằng URL thực tế
curl https://binance-p2p-api-xxxxx-as.a.run.app/health
curl https://binance-p2p-api-xxxxx-as.a.run.app/api/price/best
```

---

## 💰 Free Tier Limits

**Cloud Run Free Tier (mỗi tháng):**
- ✅ 2 triệu requests
- ✅ 360,000 GB-seconds memory
- ✅ 180,000 vCPU-seconds
- ✅ 1 GB network egress

**Với config trên (256Mi, 1 CPU, min=0):**
- Chi phí: **$0/tháng** nếu < 2M requests
- Instance scale về 0 khi không dùng → tiết kiệm tối đa

---

## 🔧 Cấu Hình Nâng Cao

### 1. Tăng performance
```bash
gcloud run services update binance-p2p-api \
  --region asia-southeast1 \
  --memory 512Mi \
  --cpu 1 \
  --max-instances 10
```

### 2. Set environment variables
```bash
gcloud run services update binance-p2p-api \
  --region asia-southeast1 \
  --set-env-vars NODE_ENV=production,LOG_LEVEL=info
```

### 3. Set minimum instances (giảm cold start)
```bash
gcloud run services update binance-p2p-api \
  --region asia-southeast1 \
  --min-instances 1
# ⚠️ Lưu ý: min-instances > 0 sẽ tốn phí ngay cả khi không có traffic
```

### 4. Xem logs
```bash
gcloud logging read "resource.type=cloud_run_revision AND resource.labels.service_name=binance-p2p-api" --limit 50
```

### 5. Update service
```bash
# Deploy version mới
gcloud run deploy binance-p2p-api \
  --source . \
  --region asia-southeast1
```

### 6. Xóa service
```bash
gcloud run services delete binance-p2p-api --region asia-southeast1
```

---

## 📊 Monitoring

### Xem metrics trong Console
```
https://console.cloud.google.com/run/detail/asia-southeast1/binance-p2p-api/metrics
```

### Check requests/CPU/Memory:
- Requests count
- Request latency
- CPU utilization
- Memory utilization
- Instance count

---

## 🎨 Custom Domain (Tùy chọn)

### Map custom domain
```bash
gcloud run domain-mappings create \
  --service binance-p2p-api \
  --domain api.yourdomain.com \
  --region asia-southeast1
```

---

## 🔒 Security (Nâng cao)

### 1. Bật authentication (không public)
```bash
gcloud run services update binance-p2p-api \
  --region asia-southeast1 \
  --no-allow-unauthenticated
```

### 2. Add API key protection (trong code)
```javascript
// Thêm middleware trong index.js
const API_KEY = process.env.API_KEY || 'your-secret-key';

app.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
});
```

---

## 🐛 Troubleshooting

### Lỗi "Permission denied"
```bash
# Enable APIs
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com

# Set billing account (cần có billing account)
gcloud beta billing projects link binance-p2p-api --billing-account=XXXXXX-XXXXXX-XXXXXX
```

### Lỗi "Container failed to start"
```bash
# Check logs
gcloud logging read "resource.type=cloud_run_revision" --limit 100

# Test Docker locally
docker build -t test .
docker run -p 8080:8080 test
```

### API timeout
```bash
# Tăng timeout (mặc định 300s)
gcloud run services update binance-p2p-api \
  --region asia-southeast1 \
  --timeout 60
```

---

## 📝 Notes

1. **Binance API không cần authentication** - API này chỉ đọc dữ liệu public
2. **Rate limiting**: Binance P2P API có rate limit, nên cân nhắc thêm caching
3. **Cold start**: Instance đầu tiên có thể mất 2-5s để start
4. **Region**: Dùng `asia-southeast1` (Singapore) để latency thấp từ VN

---

## 📚 Tài Liệu Tham Khảo

- [Cloud Run Documentation](https://cloud.google.com/run/docs)
- [Cloud Run Pricing](https://cloud.google.com/run/pricing)
- [Binance P2P API](https://p2p.binance.com)

---

## 🎯 Quick Start Commands

```bash
# 1. Install dependencies
npm install

# 2. Test locally
npm start

# 3. Deploy to Cloud Run
gcloud run deploy binance-p2p-api \
  --source . \
  --platform managed \
  --region asia-southeast1 \
  --allow-unauthenticated \
  --memory 256Mi

# 4. Get URL and test
gcloud run services describe binance-p2p-api \
  --region asia-southeast1 \
  --format 'value(status.url)'
```

---

**🎉 Chúc bạn deploy thành công!**
